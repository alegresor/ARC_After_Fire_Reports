var wms_layers = [];
var format_USA_States_0 = new ol.format.GeoJSON();
var features_USA_States_0 = format_USA_States_0.readFeatures(json_USA_States_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_USA_States_0 = new ol.source.Vector({
    attributions: '<a href=""></a>',
});
jsonSource_USA_States_0.addFeatures(features_USA_States_0);var lyr_USA_States_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_USA_States_0, 
                style: style_USA_States_0,
                title: '<img src="styles/legend/USA_States_0.png" /> USA_States'
            });var format_Rails_1 = new ol.format.GeoJSON();
var features_Rails_1 = format_Rails_1.readFeatures(json_Rails_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Rails_1 = new ol.source.Vector({
    attributions: '<a href=""></a>',
});
jsonSource_Rails_1.addFeatures(features_Rails_1);var lyr_Rails_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Rails_1, 
                style: style_Rails_1,
                title: '<img src="styles/legend/Rails_1.png" /> Rails'
            });

lyr_USA_States_0.setVisible(true);lyr_Rails_1.setVisible(true);
var layersList = [lyr_USA_States_0,lyr_Rails_1];
lyr_USA_States_0.set('fieldAliases', {'REGION': 'REGION', 'DIVISION': 'DIVISION', 'STATEFP': 'STATEFP', 'STATENS': 'STATENS', 'GEOID': 'GEOID', 'STUSPS': 'STUSPS', 'NAME': 'NAME', 'LSAD': 'LSAD', 'MTFCC': 'MTFCC', 'FUNCSTAT': 'FUNCSTAT', 'ALAND': 'ALAND', 'AWATER': 'AWATER', 'INTPTLAT': 'INTPTLAT', 'INTPTLON': 'INTPTLON', });
lyr_Rails_1.set('fieldAliases', {'LINEARID': 'LINEARID', 'FULLNAME': 'FULLNAME', 'MTFCC': 'MTFCC', });
lyr_USA_States_0.set('fieldImages', {'REGION': 'TextEdit', 'DIVISION': 'TextEdit', 'STATEFP': 'TextEdit', 'STATENS': 'TextEdit', 'GEOID': 'TextEdit', 'STUSPS': 'TextEdit', 'NAME': 'TextEdit', 'LSAD': 'TextEdit', 'MTFCC': 'TextEdit', 'FUNCSTAT': 'TextEdit', 'ALAND': 'TextEdit', 'AWATER': 'TextEdit', 'INTPTLAT': 'TextEdit', 'INTPTLON': 'TextEdit', });
lyr_Rails_1.set('fieldImages', {'LINEARID': 'TextEdit', 'FULLNAME': 'TextEdit', 'MTFCC': 'TextEdit', });
lyr_USA_States_0.set('fieldLabels', {'REGION': 'no label', 'DIVISION': 'no label', 'STATEFP': 'no label', 'STATENS': 'no label', 'GEOID': 'no label', 'STUSPS': 'no label', 'NAME': 'inline label', 'LSAD': 'no label', 'MTFCC': 'no label', 'FUNCSTAT': 'no label', 'ALAND': 'no label', 'AWATER': 'no label', 'INTPTLAT': 'no label', 'INTPTLON': 'no label', });
lyr_Rails_1.set('fieldLabels', {'LINEARID': 'no label', 'FULLNAME': 'no label', 'MTFCC': 'no label', });
lyr_Rails_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});