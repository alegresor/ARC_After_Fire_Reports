var wms_layers = [];
var format_Chicago_ZipCodes_0 = new ol.format.GeoJSON();
var features_Chicago_ZipCodes_0 = format_Chicago_ZipCodes_0.readFeatures(json_Chicago_ZipCodes_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Chicago_ZipCodes_0 = new ol.source.Vector({
    attributions: '<a href=""></a>',
});
jsonSource_Chicago_ZipCodes_0.addFeatures(features_Chicago_ZipCodes_0);var lyr_Chicago_ZipCodes_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Chicago_ZipCodes_0, 
                style: style_Chicago_ZipCodes_0,
                title: '<img src="styles/legend/Chicago_ZipCodes_0.png" /> Chicago_ZipCodes'
            });var format_Assistance_by_ZipCode_1 = new ol.format.GeoJSON();
var features_Assistance_by_ZipCode_1 = format_Assistance_by_ZipCode_1.readFeatures(json_Assistance_by_ZipCode_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Assistance_by_ZipCode_1 = new ol.source.Vector({
    attributions: '<a href=""></a>',
});
jsonSource_Assistance_by_ZipCode_1.addFeatures(features_Assistance_by_ZipCode_1);var lyr_Assistance_by_ZipCode_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Assistance_by_ZipCode_1, 
                style: style_Assistance_by_ZipCode_1,
    title: 'Assistance_by_ZipCode<br />\
    <img src="styles/legend/Assistance_by_ZipCode_1_0.png" /> 0 - 0<br />\
    <img src="styles/legend/Assistance_by_ZipCode_1_1.png" /> 0 - 200<br />\
    <img src="styles/legend/Assistance_by_ZipCode_1_2.png" /> 200 - 935<br />\
    <img src="styles/legend/Assistance_by_ZipCode_1_3.png" /> 935 - 1185<br />\
    <img src="styles/legend/Assistance_by_ZipCode_1_4.png" /> 1185 - 12695<br />'
        });

lyr_Chicago_ZipCodes_0.setVisible(true);lyr_Assistance_by_ZipCode_1.setVisible(true);
var layersList = [lyr_Chicago_ZipCodes_0,lyr_Assistance_by_ZipCode_1];
lyr_Chicago_ZipCodes_0.set('fieldAliases', {'objectid': 'objectid', 'shape_area': 'shape_area', 'shape_len': 'shape_len', 'zip': 'zip', });
lyr_Assistance_by_ZipCode_1.set('fieldAliases', {'objectid': 'objectid', 'shape_area': 'shape_area', 'shape_len': 'shape_len', 'zip': 'zip', 'Incidents_Clean_Assistance_real': 'Incidents_Clean_Assistance_real', });
lyr_Chicago_ZipCodes_0.set('fieldImages', {'objectid': 'TextEdit', 'shape_area': 'TextEdit', 'shape_len': 'TextEdit', 'zip': 'TextEdit', });
lyr_Assistance_by_ZipCode_1.set('fieldImages', {'objectid': 'TextEdit', 'shape_area': 'TextEdit', 'shape_len': 'TextEdit', 'zip': 'TextEdit', 'Incidents_Clean_Assistance_real': 'TextEdit', });
lyr_Chicago_ZipCodes_0.set('fieldLabels', {'objectid': 'no label', 'shape_area': 'no label', 'shape_len': 'no label', 'zip': 'no label', });
lyr_Assistance_by_ZipCode_1.set('fieldLabels', {'objectid': 'no label', 'shape_area': 'no label', 'shape_len': 'no label', 'zip': 'no label', 'Incidents_Clean_Assistance_real': 'no label', });
lyr_Assistance_by_ZipCode_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});